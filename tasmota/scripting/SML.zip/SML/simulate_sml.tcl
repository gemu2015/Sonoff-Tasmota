SET SCREEN 300 400 100 50 "Emulate SML Meter"
NEW SCREEN

// several example def files are provided 
// hex def files may not have more then 98 values per line
// a pause between blocks may be inserted by P: X  (X number of milliseconds)

CLR SCREEN C_WH8
INCLUDE "paket/glob_macros.tcl"


DEFINE PATH "home"

s99=""
b994=1
sbaud=0
exp_spname=""
mode=0
obis=""
hex=""
smlfile="-"
logref=0
value=4000

cfgfile="/simulate_sml.cfg"

b1=CHKFILE cfgfile
if b1>0
then
	RESTORE cfgfile
endif

NFORMAT = 1.0

logtext="log"

:restart
exp_defpath = "/DEF/" + s99

smlfile=s99
gosub :read_def


cxp=10
cyp=10
cxs=200
cys=30
ccs=16
cdx=5
cdy=20
val_num=1

brate=0
brate=b998
fnref=0

cxp=50
cyp=50

Button "Serial setup" 1 's'

Button smlfile 5 'f'
fnref=CREF
cxp=50

RangeOfNumbers "Blocks" 970 1 10 7

Button "Transmit SML" 2 't'

Value "TX: %2.0f" -801
cyp+=cdy+cys
cxp=50

Button logtext 10 0
logref=CREF


Button "Exit" 3 'q'

TIMEOUT=0
:loop
cmd=0
cmd=CONTROLS
if cmd==1
	goto :ssetup
if cmd==2
	goto :start
if cmd==3
	goto :ende
if cmd==5
	goto :select
	
loop  :loop

:select
DIRPATH=PATH+"/DEF/"
FEXTENS="def"
s1=SELECT 0 "select def file"
if s1 =""
	goto :loop

smlfile=STRTOK(s1 "/" 99)
s99=smlfile
COPT fnref 0 smlfile
exp_defpath = "/DEF/" + smlfile
gosub :read_def
goto :loop

:start
	
//exp_spname="usbserial-14301"
b1=SCHECK exp_spname
if b1<0
then
	MESSAGE "serial port not found"
	END
endif

SOPEN2  exp_spname sbaud


b801=0
valcnt=0
for valcnt 1 b970 1
	if mode==0
	then
		// hex
		gosub :send_hex
	else
		// obis
		gosub :send_obis
	endif
	b801+=1
	TICKS 1000
next


SCLOSE2

loop :loop

// setup serial
:ssetup
suxp=100
suyp=300
SBOX "Serial parameters" suxp suyp-200 990 98 998 992 99
b994=0
SET SPORT exp_spname b998-1 b994 

sbaud=b998-1
//print exp_spname TAB b998 TAB b994
exp_defpath = "/DEF/" + s99
smlfile=s99

COPT fnref 0 smlfile

gosub :read_def

// store cfg
STORE cfgfile 1
KILL CONTROLS
loop :restart


:read_def
s2=FILESTR exp_defpath 1
s1=s2
s1=STRTOK(s1 " " 1)

if s1=="HEX"
then
	hex=FILESTR exp_defpath 0
	hex=STRTOK(hex "\n" -2)
	//gosub :send_hex
	mode=0
endif

if s1=="ASCI"
then
	mode=1
	obis=FILESTR exp_defpath 0
	s2=s2+"\n"
	obis=STRTOK(obis s2 2)
	//gosub :send_obis
endif

return

:send_hex


SET ALEN a1 1000
	
s1=STRTOK(hex "\n" 0)
lincnt=0
lincnt=STRNUM(s1)

lcnt=0
bcnt=0
for lcnt 1 lincnt 1 
	cnt=0
	s10 = STRTOK(hex "\n" lcnt)
	b1 = INSTR(s10 "P:")
	b2 = INSTR(s10 "V:")
	if b1>=0
	then
		// pause
		s1 = STRTOK(s10 "P:" 2)
		b1 = STRNUM(s1)
		logtext = NUMSTR("WAIT %1.0f ms" b1)
		COPT logref 0 logtext
		TICKS(b1)
		logtext="---"
		COPT logref 0 logtext
	else
		if b2>=0
		then
			s1 = STRTOK(s10 "V:" 2)
			b1 = STRNUM(s1)
			// 4 bytes value
			a1=value>>24&0xff
			a1=value>>16&0xff
			a1=value>>8&0xff
			a1=value&0xff
			value+=b1
		else 
			b11=s10[0]
			b10=b11/3+1
			//print b10 TAB b11 TAB s10 LF
			for cnt 1 b10 1
				s1=STRTOK(s10 " " cnt)
				if s1==""
				then
					break
				endif
				b1=HSTRNUM(s1)
				a1 = b1
				bcnt+=1
				//s10=NUMSTRX("%02x" b1)
				//print cnt TAB s1 TAB b1 LF
			next
		endif
	endif
next

SWABF2 1 bcnt

NFORMAT = 1.0
//print "sending " b10 " binary values" LF
logtext = NUMSTR("%1.0f bytes sent" bcnt)
COPT logref 0 logtext

TICKS 100

return

:send_obis
cnt=0
b10=0
s10=STRTOK(obis "\n" 0)
b12=STRNUM(s10)
for cnt 1 b12 1
	s10=STRTOK(obis "\n" cnt)
	if s10==""
	then
		break
	endif
	b1 = INSTR(s10 "P:")
	if b1>=0
	then
		// pause
		s1 = STRTOK(s10 "P:" 2)
		b1 = STRNUM(s1)
		logtext = NUMSTR("WAIT %1.0f ms" b1)
		COPT logref 0 logtext
		TICKS(b1)
		logtext="---"
		COPT logref 0 logtext
	else
		SWRITE2 s10
		SWRITE2 "\r\n"
		b10+=1
		//print s10 LF
	endif
next

logtext = NUMSTR("%1.0f lines sent" b10)
COPT logref 0 logtext

return


:ende
STORE cfgfile 1
END




