#!/bin/bash
# SML / OBIS Meter Emulator - Tasmota
# Modbus TCP Port 502 erfordert Root-Rechte.
# Starte mit: sudo ./sml_emulator.sh
# Oder: sudo setcap cap_net_bind_service=+ep $(which python3)

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo " SML / OBIS Meter Emulator - Tasmota"
echo " ====================================="
echo ""

# Find python3
PYTHON=""
for p in python3 python; do
    if command -v "$p" &>/dev/null; then
        PYTHON="$p"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo " FEHLER: Python 3 nicht gefunden!"
    echo " Bitte installieren:"
    echo "   Ubuntu/Debian: sudo apt install python3 python3-pip"
    echo "   Fedora:        sudo dnf install python3 python3-pip"
    echo ""
    exit 1
fi

# Check pyserial
if ! "$PYTHON" -c "import serial" &>/dev/null; then
    echo "Installiere pyserial..."
    "$PYTHON" -m pip install pyserial --break-system-packages 2>/dev/null \
        || "$PYTHON" -m pip install pyserial
fi

# Warn if not root (port 502 needs root)
if [ "$EUID" -ne 0 ]; then
    echo " HINWEIS: Modbus TCP Port 502 erfordert Root-Rechte."
    echo " Falls der Modbus TCP Slave nicht startet:"
    echo "   sudo $0"
    echo " Oder einmalig:  sudo setcap cap_net_bind_service=+ep \$(which python3)"
    echo ""
fi

echo "Starte SML Emulator..."
echo ""
exec "$PYTHON" "${SCRIPT_DIR}/sml_emulator_server.py"
