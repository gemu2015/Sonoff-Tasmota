@echo off
chcp 65001 >nul
title SML Emulator - Tasmota
echo.
echo  SML / OBIS Meter Emulator - Tasmota
echo  =====================================
echo.
echo  HINWEIS: Modbus TCP Port 502 erfordert Administratorrechte.
echo  Falls der Modbus TCP Slave nicht startet, dieses Skript als
echo  Administrator ausfuehren (Rechtsklick -> Als Administrator ausfuehren).
echo.

set PYTHON=
where python >nul 2>&1
if %errorlevel% equ 0 set PYTHON=python

if "%PYTHON%"=="" (
    where python3 >nul 2>&1
    if %errorlevel% equ 0 set PYTHON=python3
)

if "%PYTHON%"=="" (
    where py >nul 2>&1
    if %errorlevel% equ 0 set PYTHON=py
)

if "%PYTHON%"=="" (
    echo.
    echo  FEHLER: Python wurde nicht gefunden!
    echo.
    echo  Bitte Python 3 installieren:
    echo  https://www.python.org/downloads/
    echo.
    echo  WICHTIG: Bei der Installation das Haekchen bei
    echo  "Add Python to PATH" setzen!
    echo.
    pause
    exit /b 1
)

echo Pruefe pyserial...
%PYTHON% -c "import serial" >nul 2>&1
if %errorlevel% neq 0 (
    echo Installiere pyserial...
    %PYTHON% -m pip install pyserial
    if %errorlevel% neq 0 (
        echo.
        echo  FEHLER: pyserial konnte nicht installiert werden.
        echo  Bitte manuell ausfuehren: pip install pyserial
        echo.
        pause
        exit /b 1
    )
)

echo Starte SML Emulator...
echo.
%PYTHON% "%~dp0sml_emulator_server.py"

:end
pause
