Shelly / EcoTracker Tester — Cross-Platform Port
=================================================

Browser-based UI for testing Shelly and EcoTracker devices over UDP
(default port 1010), HTTP GET, or ICMP ping.

Original by ottelo: https://ottelo.jimdofree.com/

Requirement:
  Python 3 (usually pre-installed on Linux)

Setup:
  chmod +x shelly_tester.sh

Run:
  ./shelly_tester.sh
  The browser opens automatically with the UI.

Features:
  - UDP request/response with optional persistent listener
  - HTTP GET to any device URL
  - ICMP ping with statistics + optional log file
  - Periodic interval mode (re-send every N seconds)
  - Color-coded log + auto-formatted JSON view

Stop:
  Close the browser tab and press Ctrl+C in the terminal.

Note for Ping mode:
  Some distros require root or cap_net_raw to send ICMP. If ping
  always fails, run once with sudo, or set the capability:
    sudo setcap cap_net_raw+ep $(which python3)
