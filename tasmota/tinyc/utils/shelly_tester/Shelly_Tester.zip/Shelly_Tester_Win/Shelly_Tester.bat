@echo off
chcp 65001 >nul
title Shelly / EcoTracker Tester
echo.
echo  Shelly / EcoTracker Tester
echo  ==========================
echo.
where python >/dev/null 2>&1
if %errorlevel% equ 0 (
    python "%~dp0shelly_tester_gui.py"
    goto :end
)
where py >/dev/null 2>&1
if %errorlevel% equ 0 (
    py "%~dp0shelly_tester_gui.py"
    goto :end
)
echo.
echo  FEHLER: Python 3 wurde nicht gefunden!
echo.
echo  Bitte Python 3 installieren:
echo  https://www.python.org/downloads/
echo  WICHTIG: Bei der Installation "Add Python to PATH" anhaken!
echo.
:end
pause
