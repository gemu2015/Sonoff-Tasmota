Tasmota Workbench — Linux

1. Install deps:    pip3 install --user pyserial
   (Serial access usually needs the dialout group: sudo usermod -aG dialout "$USER", then re-login.)
2. Run:             ./tasmota_workbench.sh
   Or set up the .desktop file (a copy of which is bundled here).

It opens http://127.0.0.1:8124/ in your browser. Three panes:
  Monitor — serial / UDP-syslog console
  Devices — LAN scan + OTA flash + inline rename
  Shares  — Tasmota multicast share-protocol monitor (239.255.255.250:1999)
