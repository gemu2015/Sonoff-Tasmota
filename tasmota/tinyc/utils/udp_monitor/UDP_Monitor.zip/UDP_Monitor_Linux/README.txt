UDP Monitor - Tasmota Multicast Variables
==========================================

Displays all UDP multicast variables broadcast by Tasmota devices
on your local network.

Requirement:
  Python 3 (usually pre-installed on Linux)

Setup:
  chmod +x udp_monitor.sh

Run:
  ./udp_monitor.sh
  The browser opens automatically with the UI.

Usage:
  1. Choose scan duration (default: 60 seconds)
  2. Click "Start Scan"
  3. The program listens for UDP multicast packets
  4. After the scan, all variables are displayed:
     - Sender IP and device name
     - Variable name, type, and current value
     - Send interval and receive count
     - Name clashes (same name from multiple devices)
  5. Export results as CSV

Sort columns by clicking on column headers.

Stop:
  Close the browser tab and press Ctrl+C in the terminal.

Note:
  If no packets are received, check that your firewall allows
  UDP multicast on port 1999 (group 239.255.255.250):
    sudo ufw allow 1999/udp
