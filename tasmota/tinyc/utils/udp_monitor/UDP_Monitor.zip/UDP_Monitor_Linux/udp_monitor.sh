#!/bin/bash
echo ""
echo "  UDP Monitor - Tasmota Multicast Variables"
echo "  =========================================="
echo ""

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if command -v python3 &>/dev/null; then
    echo "Starting UDP Monitor..."
    python3 "$SCRIPT_DIR/udp_monitor_gui.py"
elif command -v python &>/dev/null; then
    echo "Starting UDP Monitor..."
    python "$SCRIPT_DIR/udp_monitor_gui.py"
else
    echo "  ERROR: Python 3 not found!"
    echo ""
    echo "  Install Python 3 using your package manager:"
    echo "    Ubuntu/Debian:  sudo apt install python3"
    echo "    Fedora:         sudo dnf install python3"
    echo "    Arch:           sudo pacman -S python"
    echo ""
fi
