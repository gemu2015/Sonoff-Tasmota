@echo off
chcp 65001 >nul
title UDP Monitor - Tasmota
echo.
echo  UDP Monitor - Tasmota Multicast Variablen
echo  ==========================================
echo.

where python >nul 2>&1
if %errorlevel% equ 0 (
    echo Starte UDP Monitor...
    python "%~dp0udp_monitor_gui.py"
    goto :end
)

where python3 >nul 2>&1
if %errorlevel% equ 0 (
    echo Starte UDP Monitor...
    python3 "%~dp0udp_monitor_gui.py"
    goto :end
)

where py >nul 2>&1
if %errorlevel% equ 0 (
    echo Starte UDP Monitor...
    py "%~dp0udp_monitor_gui.py"
    goto :end
)

echo.
echo  FEHLER: Python wurde nicht gefunden!
echo.
echo  Bitte Python 3 installieren:
echo  https://www.python.org/downloads/
echo.
echo  WICHTIG: Bei der Installation das Häkchen bei
echo  "Add Python to PATH" setzen!
echo.

:end
pause
